from pathlib import Path
D=Path(__file__).resolve().parent
prefix=('DELETED2','STEP ','HISTOGRAM ')
def lines(name):
 return sorted(x.strip() for x in (D/name).read_text().splitlines() if x.startswith(prefix))
a,b=lines('python_verification.txt'),lines('cpp_verification.txt')
assert a==b and len(a)==109
print('PASS: 109 matching new exact computation lines.')
