from pathlib import Path
import hashlib,zipfile
D=Path(__file__).resolve().parent
for line in (D/'SHA256SUMS.txt').read_text().splitlines():
 h,p=line.split('  ',1)
 assert hashlib.sha256((D/p).read_bytes()).hexdigest()==h,p
with zipfile.ZipFile(D/'baseline277_certificate.zip') as z:
 for name in z.namelist():
  if name.endswith('/'):continue
  rel=Path(name).relative_to('cap7_upper277')
  assert (D/'baseline277'/rel).read_bytes()==z.read(name),str(rel)
print('PASS: all recorded file hashes and preserved baseline files match.')
