#!/usr/bin/env python3
from pathlib import Path
import json,sys,copy
W=Path(__file__).resolve().parents[1]
S=int(sys.argv[1]) if len(sys.argv)>1 else 277
p=W/'results'/f'size{S}'
c=json.loads((p/'certificate.json').read_text())
# Derived seed: two completed slices with two deletions in total.
c['seeds']=[[112,112,29],[112,111,35],[112,110,45],[111,111,45]]
c['initial_seeds']=[[112,112,29],[112,111,35]]
c['new_histograms']=[json.loads((W/'results/histograms'/f'{hid}.json').read_text()) for hid in c.get('histogram_inputs',[])]
for hp in sorted(p.glob('nested[0-9]*.json')):
 if not hp.stem.removeprefix('nested').isdigit():continue
 h=json.loads(hp.read_text());m=h['m'];key=','.join(map(str,h['outer']['type']));r=h['outer'];q=r['coeff'];label=f'nested{m}_size{S}'
 h['id']=label;c['new_histograms'].append(h)
 rec=dict(coeff=[q[0],q[1],q[2],q[1],q[2],q[3],q[4],1,1],K=r['K'],forced=r['forced'],gap=r['gap'],status=[0,0,-1],extra_features=[[0,label],[1,label]])
 br=c['extremal'][key]['branches'];br=[z for z in br if z['status']!=[0,0,-1]]+[rec];br.sort(key=lambda z:z['status']);c['extremal'][key]['branches']=br;c['extremal'][key]['success']=len(br)==4
for key in list(c['extremal']):
 t=list(map(int,key.split(',')))
 if any(all(a>=b for a,b in zip(t,u)) for u in c['seeds']):del c['extremal'][key]
assert all(r.get('success',True) for r in c['extremal'].values()),'Some extremal branches are unresolved'
(p/'proof.json').write_text(json.dumps(c,indent=2))
print('Assembled candidate',p/'proof.json','ordinary',[len(st) for st in c['stages']],'extremal',len(c['extremal']))
