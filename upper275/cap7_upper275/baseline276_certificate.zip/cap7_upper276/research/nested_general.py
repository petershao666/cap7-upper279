#!/usr/bin/env python3
"""Jointly discover a six-dimensional noncompletion histogram bound and an outer inequality."""
import os;os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['OMP_NUM_THREADS']='1'
from pathlib import Path
import sys,json,math,itertools,argparse,time
import numpy as np
from scipy.optimize import linprog
sys.path.insert(0,str(Path(__file__).resolve().parent))
from search_target import W,B,p,en,force,obj,types,separation,SEEDS
sys.path.insert(0,str(B/'research'))
from nested108 import inner_enum
from engine import make_adm,make_top

def support(m):return [(a,b,m-a-b) for a in range(46) for b in range(a+1) if 0<=m-a-b<=b and p.old.downwards_allowed((a,b,m-a-b),p.F6+p.comp)]
def choose_rare(m,T):
 # Search simple slopes preferring few anchors with large first section.
 tot=np.array([243*math.comb(m,2),81*math.comb(m,3)],np.int64);options=[]
 for den in [1,2,5,10,20,50,100]:
  for num in range(37*den,41*den+1):
   U=den*int(tot[1])-num*int(tot[0]);K=U//364+1
   R=[t for t in T if den*p.old.e3(t)-num*p.old.e2(t)<K]
   if min(t[0] for t in R)<40:continue
   options.append((len(R),den,num,R,K,U))
 _,den,num,R,K,U=min(options,key=lambda x:(x[0],x[1]))
 return R,dict(coeff=[-num,den],K=K,forced=U,gap=364*K-U)

EXTRA5=[(20,19,2),(20,18,3),(19,19,3),(19,18,4)]

def inner_data(key,m,T,extra5=False):
 ix={t:i for i,t in enumerate(T)};index=np.full((46,46),-1,np.int64)
 for t,i in ix.items():index[t[0],t[1]]=i
 adm=make_adm(5,np.asarray(EXTRA5 if extra5 else [],np.int64).reshape(-1,3));top=make_top(45,m,np.asarray(p.F6+p.comp,np.int64))
 arr=inner_enum(*key,adm,top,index)
 eq=arr[:,:7].copy();tot=list(force(key,6));extra=[];spectra=[];uppercuts=[];upper_columns=[]
 for j,N in enumerate(key):
  if str(N) not in p.cert['spectrum5']:continue
  data=p.cert['spectrum5'][str(N)];tt=data['types'];hist=data['spectra']
  inds={tuple(t):i for i,t in enumerate(tt)}
  idx=np.array([inds[tuple(t)] for t in arr[:,7+3*j:10+3*j]],np.int32)
  if len(hist)==1:
   for k,t in enumerate(tt):
    eq=np.c_[eq,(idx==k).astype(np.int64)];tot.append(hist[0][k]);extra.append((j,t))
  else:spectra.append(dict(column=j,types=tt,hist=np.asarray(hist,np.int64),idx=idx))
 for j,N in enumerate(key):
  cp=W/'research/smallcaps'/f'cuts{N}.json'
  if not cp.exists():continue
  for ci,cut in enumerate(json.loads(cp.read_text())):
   ixcut={tuple(t):v for t,v in zip(cut['types'],cut['phi'])}
   vals=np.array([ixcut[tuple(t)] for t in arr[:,7+3*j:10+3*j]],np.int64)
   upper_columns.append(eq.shape[1]);eq=np.c_[eq,vals];tot.append(cut['bound']);uppercuts.append(dict(column=j,id=f'hist5_{N}_{ci}',data=cut))
 return dict(key=key,arr=arr,rows=eq,totals=np.array(tot,np.int64),extras=extra,spectra=spectra,uppercuts=uppercuts,upper_columns=upper_columns)

def run(S,m,key,extra5=False):
 T=support(m);ix={t:i for i,t in enumerate(T)};RARE,root=choose_rare(m,T)
 print('SUPPORT',m,len(T),'RARE',RARE,'ROOT',root,flush=True)
 path=W/'results'/f'size{S}'/'certificate.json';cert=json.load(open(path));k=cert['k']
 excluded=SEEDS+[(112,110,45),(111,111,45)]+[p.old.parse_key(t) for st in cert['stages'] for t in st]
 excluded +=[t for t in types(S) if obj(S,k,t)<obj(S,k,key)]
 arr=en(key,excluded);mask=np.ones(len(arr),bool)
 for j in (0,1):
  for t in p.comp:mask &=~np.all(arr[:,7+3*j:10+3*j]>=t,axis=1)
 arr=arr[mask]
 X=np.c_[arr[:,0],arr[:,1]+arr[:,3],arr[:,2]+arr[:,4],arr[:,5],arr[:,6]].astype(np.int64)
 FF=force(key);F=np.array([FF[0],FF[1]+FF[3],FF[2]+FF[4],FF[5],FF[6]],np.int64)
 V=X-F/364;scale=np.maximum(np.max(abs(V),axis=0),1);V/=scale
 ia=np.array([ix[tuple(t)] for t in arr[:,7:10]],np.int32);ib=np.array([ix[tuple(t)] for t in arr[:,10:13]],np.int32)
 print('OUTER',key,len(arr),flush=True)
 poff=5;boff=poff+len(T);offset=boff+1;inners=[];bounds=[(-1,1)]*boff+[(None,None)]
 for t in RARE:
  z=inner_data(t,m,T,extra5);vv=z['rows']-z['totals']/121;sc=np.maximum(np.max(abs(vv),axis=0),1);vv/=sc
  z.update(W=vv,scale=sc,offset=offset);offset+=z['rows'].shape[1];bounds +=[(0,1) if i in z['upper_columns'] else (-1,1) for i in range(z['rows'].shape[1])]
  for sp in z['spectra']:
   sp['offset']=offset;offset+=len(sp['types']);bounds +=[(-1,1)]*len(sp['types']);sp['zoff']=offset;offset+=1;bounds.append((None,None))
  inners.append(z)
 nv=offset+1;delt=offset;bounds.append((None,None))
 print('VARIABLES',nv,'INNER',[len(z['arr']) for z in inners],flush=True)
 fixed=[]
 for z in inners:
  n=len(z['arr']);R=np.zeros((n,nv));R[:,z['offset']:z['offset']+z['rows'].shape[1]]=-z['W']
  for k0 in range(3):R[np.arange(n),poff+z['arr'][:,16+k0]]+=1
  R[:,poff+ix[z['key']]]+=1/121;R[:,boff]=-364/121
  for sp in z['spectra']:
   R[np.arange(n),sp['offset']+sp['idx']]-=1;R[:,sp['zoff']]+=1
   sr=np.zeros((len(sp['hist']),nv));sr[:,sp['offset']:sp['offset']+len(sp['types'])]=sp['hist']/121;sr[:,sp['zoff']]=-1;fixed.append(sr)
  z['dual_start']=sum(len(b) for b in fixed);z['dual_count']=n;fixed.append(R)
 fixed=np.concatenate(fixed);inds=np.unique(np.r_[np.argmin(V,axis=0),np.argmax(V,axis=0)]);sol=None
 print('FIXED_ROWS',len(fixed),flush=True)
 for it in range(500):
  R=np.zeros((len(inds),nv));R[:,:5]=-V[inds];R[np.arange(len(inds)),poff+ia[inds]]-=1;R[np.arange(len(inds)),poff+ib[inds]]-=1;R[:,boff]=2;R[:,delt]=1
  res=linprog(np.r_[np.zeros(nv-1),-1.],A_ub=np.r_[fixed,R],b_ub=np.zeros(len(fixed)+len(R)),bounds=bounds,method='highs')
  if not res.success:print('SOLVER',res.message,flush=True);break
  x=res.x;gap=x[-1];vals=V@x[:5]+x[poff+ia]+x[poff+ib]-2*x[boff];lo=vals.min()
  print('ITER',it,'rows',len(inds),'gap',gap,'min',lo,flush=True)
  if gap<1e-9:break
  if lo>=gap-1e-9:sol=x;break
  add=np.argpartition(vals,min(99,len(vals)-1))[:100];inds=np.unique(np.r_[inds,add])
 folder=W/'results'/f'size{S}';save=folder/f'nested{m}_'+Path('') if False else folder/f'nested{m}_'+'' if False else folder/f'nested{m}.json'
 if sol is None:
  witnesses=[]
  if res.success:
   weights=-res.ineqlin.marginals
   for z in inners:
    w=weights[z['dual_start']:z['dual_start']+z['dual_count']];mass=w.sum()
    if mass<1e-10:continue
    for j,N in enumerate(z['key']):
     if N not in (40,41):continue
     tt=sorted(set(map(tuple,z['arr'][:,7+3*j:10+3*j])));h=[]
     for t in tt:h.append(float(121*w[np.all(z['arr'][:,7+3*j:10+3*j]==t,axis=1)].sum()/mass))
     witnesses.append(dict(anchor=z['key'],m=N,column=j,types=tt,histogram=h,mass=float(mass),moments_residual=[float(sum(v*p.old.e2(t) for v,t in zip(h,tt))-81*math.comb(N,2)),float(sum(v*p.old.e3(t) for v,t in zip(h,tt))-27*math.comb(N,3))]))
  (folder/f'nested{m}_witness.json').write_text(json.dumps(witnesses,indent=2,default=int))
  (folder/f'nested{m}_failure.json').write_text(json.dumps(dict(status='numerically_unresolved',iteration=it,gap=float(gap) if res.success else None,message=res.message),indent=2));return
 floats=sol.copy();floats[:5]/=scale
 for z in inners:floats[z['offset']:z['offset']+z['rows'].shape[1]]/=z['scale']
 for mul in (1000,10000,100000,1000000,10000000,100000000,1000000000,10000000000):
  qi=np.rint(floats*mul).astype(np.int64);q=qi[:5];phi=qi[poff:boff];inner_c=[];Bs=[]
  for z in inners:
   qin=qi[z['offset']:z['offset']+z['rows'].shape[1]];val=z['rows']@qin-np.sum(phi[z['arr'][:,16:19]],axis=1);U=sum(int(a)*int(b) for a,b in zip(qin,z['totals']));spec=[]
   for sp in z['spectra']:
    qp=qi[sp['offset']:sp['offset']+len(sp['types'])];bound=int(np.max(sp['hist']@qp));val+=qp[sp['idx']];U+=bound;spec.append(dict(column=sp['column'],types=sp['types'],phi=qp.tolist(),bound=bound))
   K=int(val.min());Bb=int(phi[ix[z['key']]])+U-121*K;Bs.append(Bb)
   inner_c.append(dict(type=z['key'],coeff=qin.tolist(),K=K,bound=Bb,extras=z['extras'],spectra=spec,uppercuts=z['uppercuts'],discovery_matrices=len(val)))
  Bbound=max(Bs);val=X@q+phi[ia]+phi[ib];K=int(val.min());forced=sum(int(a)*int(b) for a,b in zip(q,F))+2*Bbound;gap=364*K-forced
  print('RECOVER',mul,'gap',gap,'bound',Bbound,flush=True)
  if gap>0:
   out=dict(size=S,m=m,admissibility5_extra=EXTRA5 if extra5 else [],root=root,types=T,inner=inner_c,phi=phi.tolist(),bound=Bbound,outer=dict(type=key,coeff=q.tolist(),K=K,forced=forced,gap=gap,discovery_matrices=len(X)),seeds=SEEDS+[(112,110,45),(111,111,45)])
   save.write_text(json.dumps(out,indent=2));print('EXACT DISCOVERY PASS',save,gap,flush=True);return
 print('COEFFICIENT RECOVERY FAILURE',flush=True)
if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('size',type=int);ap.add_argument('m',type=int);ap.add_argument('--extra5',action='store_true');args=ap.parse_args();run(args.size,args.m,(args.m,args.m,args.size-2*args.m),args.extra5)
