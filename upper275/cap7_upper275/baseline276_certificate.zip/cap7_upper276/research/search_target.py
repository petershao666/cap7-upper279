#!/usr/bin/env python3
"""Parameterized discovery toward upper bounds 276,...,270. Proposals require exact verification."""
import os
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['OMP_NUM_THREADS']='1'
from pathlib import Path
import sys,json,math,itertools,time,gc,argparse
import numpy as np
from scipy.optimize import linprog
W=Path(__file__).resolve().parents[1];B=W/'baseline277'
sys.path.insert(0,str(B/'research'))
from search_stage import en
import probe as p
from engine import force
C=json.loads((B/'certificate.json').read_text())
H=C['nested108'];PHI={tuple(t):v for t,v in zip(H['types'],H['phi'])}
SEEDS=[(112,112,29),(112,111,35)]
HISTOGRAMS=[dict(id='psi108',m=108,types=H['types'],phi=H['phi'],bound=H['bound'])]
for _hpath in sorted((W/'results/histograms').glob('*.json')) if (W/'results/histograms').exists() else []:
 HISTOGRAMS.append(json.loads(_hpath.read_text()))
def types(S):return [(a,b,S-a-b) for a in range(113) for b in range(a+1) if 0<=S-a-b<=b]
def obj(S,k,t):return 9*p.old.e3(t)-(4*S-3*k)*p.old.e2(t)+S*S*(S-k)
def rootsum(S,k):return 9*243*math.comb(S,3)-(4*S-3*k)*729*math.comb(S,2)+S*S*(S-k)*1093
def separation(rows,totals,D,upper=(),log=False):
 if len(rows)==0:return dict(empty=True),dict(status='empty')
 # positive coefficients on summed upper bounds
 mean=np.asarray(totals,dtype=float)/D
 V=rows.astype(float)-mean;sc=np.maximum(np.max(abs(V),axis=0),1);V/=sc
 inds=np.unique(np.r_[np.argmin(V,axis=0),np.argmax(V,axis=0)])
 bounds=[((0,1) if j in upper else (-1,1)) for j in range(V.shape[1])]+[(None,None)]
 qs=None;report={}
 for it in range(250):
  res=linprog(np.r_[np.zeros(V.shape[1]),-1.],A_ub=np.c_[-V[inds],np.ones(len(inds))],b_ub=np.zeros(len(inds)),bounds=bounds,method='highs')
  if not res.success:return None,dict(status='solver_failure',message=res.message)
  gap=float(res.x[-1]);vals=V@res.x[:-1];m=float(vals.min())
  report=dict(status='numeric_feasible' if gap<1e-9 else 'unresolved',iterations=it+1,active=len(inds),gap=gap,minimum=m)
  if gap<1e-9:
   # Preserve a sparse numerical feasible support from dual row multipliers.
   weights=-res.ineqlin.marginals
   active=np.flatnonzero(weights>1e-10)
   report['support_indices']=inds[active].tolist();report['support_weights']=(D*weights[active]).tolist()
   report['feature_rows']=rows[inds[active]].tolist();report['totals']=list(map(int,totals));report['upper_columns']=list(upper)
   return None,report
  if m>=gap-1e-9:qs=res.x[:-1]/sc;break
  add=np.argpartition(vals,min(49,len(vals)-1))[:50];inds=np.unique(np.r_[inds,add])
 if qs is None:return None,report
 nz=abs(qs)>1e-12;qs/=min(abs(qs[nz]));R=rows.astype(np.int64,copy=False)
 for mul in (1,2,3,5,10,20,50,100,200,500,1000,2000,10000,100000,1000000):
  qi=np.rint(qs*mul).astype(np.int64);g=math.gcd(*map(int,qi));qi//=g
  if any(qi[j]<0 for j in upper):continue
  # Stay within 64-bit discovery arithmetic, final checker is unbounded.
  if sum(int(np.max(abs(R[:,j])))*abs(int(qi[j])) for j in range(len(qi)))>=2**62:continue
  K=int(np.min(R@qi));forced=sum(int(x)*int(y) for x,y in zip(qi,totals));gap=D*K-forced
  if gap>0:return dict(coeff=list(map(int,qi)),K=K,forced=forced,gap=gap),dict(status='exact_discovery',iterations=it+1,rows=len(rows))
 return None,dict(report,status='coefficient_recovery_failure')
def branch_data(arr,key,status,psi=True):
 rows,tot,extra=p.prepare(arr,key,status,True)
 # prepare can replicate labels, but raw arrays also replicated internally.
 # phi depends only on e2,e3 (fixed sum identifies a sorted triple), so map pair.
 upper=[]
 if psi:
  for j,(N,st) in enumerate(zip(key,status)):
   if st!=0:continue
   for hh in HISTOGRAMS:
    if hh['m']!=N:continue
    lookup={(p.old.e2(t),p.old.e3(t)):z for t,z in zip(hh['types'],hh['phi'])}
    pp=rows[:,[1+2*j,2+2*j]];uniq,inv=np.unique(pp,axis=0,return_inverse=True)
    vals=np.array([lookup[tuple(z)] for z in uniq],dtype=np.int64)[inv]
    rows=np.c_[rows,vals];tot=np.r_[tot,hh['bound']];upper.append(rows.shape[1]-1);extra.append((j,hh['id']))
 return rows,tot,extra,upper

def main():
 ap=argparse.ArgumentParser();ap.add_argument('size',type=int);ap.add_argument('mode',choices=['ordinary','extremal','probe']);ap.add_argument('--case',nargs=3,type=int);ap.add_argument('--cutoff',type=int,default=72);ap.add_argument('--no-psi',action='store_true');args=ap.parse_args()
 S=args.size;k=next(k for k in range(50,90) if rootsum(S,k)<0);folder=W/'results'/f'size{S}';folder.mkdir(parents=True,exist_ok=True)
 path=folder/'certificate.json';result=json.loads(path.read_text()) if path.exists() else dict(size=S,k=k,root_sum=rootsum(S,k),stages=[],extremal={})
 excluded=SEEDS+[p.old.parse_key(x) for st in result['stages'] for x in st]
 result['histogram_inputs']=[hh['id'] for hh in HISTOGRAMS if hh['id']!='psi108']
 print('START',S,args.mode,'k',k,'root sum',rootsum(S,k),'existing ordinary',len(excluded)-2,flush=True)
 keys=[tuple(args.case)] if args.case else [t for t in types(S) if t[2]<=args.cutoff and p.old.downwards_allowed(t,excluded)]
 if args.mode!='ordinary':keys=[t for t in keys if obj(S,k,t)<0];keys.sort(key=lambda t:obj(S,k,t))
 else:keys.sort(key=lambda t:(t[2],-t[0]))
 stage={}
 for key in keys:
  label=','.join(map(str,key));start=time.time();ban=excluded if args.mode=='ordinary' else excluded+[t for t in types(S) if obj(S,k,t)<obj(S,k,key)]
  arr=en(key,ban)
  rec,diag=separation(arr[:,:7],force(key),364)
  print('CASE',key,'rows',len(arr),'Q',obj(S,k,key),'certificate',rec,'status',diag['status'],'sec',round(time.time()-start,2),flush=True)
  (folder/f'{args.mode}_{label}_diagnostic.json').write_text(json.dumps(diag,indent=2))
  if rec:
   rec['discovery_rows']=len(arr)
   if args.mode=='ordinary':stage[label]=rec
   else:result['extremal'][label]=rec
  elif args.mode!='ordinary':
   elig=[j for j,N in enumerate(key) if 103<=N<109]
   branches=[]
   for bits in itertools.product((0,1),repeat=len(elig)):
    status=tuple(bits[elig.index(j)] if j in elig else (1 if key[j]>=109 else -1) for j in range(3))
    rows,tot,ex,up=branch_data(arr,key,status,not args.no_psi);rr,dd=separation(rows,tot,364,up)
    print('BRANCH',key,status,'rows',len(rows),'cert',rr,'status',dd['status'],'sec',round(time.time()-start,2),flush=True)
    (folder/f'{args.mode}_{label}_{status[0]}{status[1]}_diagnostic.json').write_text(json.dumps(dd,indent=2))
    if rr:branches.append(dict(rr,status=list(status),extra_features=ex,discovery_states=len(rows)))
    del rows;gc.collect()
   result['extremal'][label]=dict(branches=branches,required=2**len(elig),success=len(branches)==2**len(elig))
  if args.mode=='ordinary':
   tmp=dict(result);tmp['stages']=result['stages']+[stage] if stage else result['stages'];path.write_text(json.dumps(tmp,indent=2))
  else:path.write_text(json.dumps(result,indent=2))
  del arr;gc.collect()
 print('FINISH',S,args.mode,'stage',len(stage),flush=True)

if __name__=='__main__':main()
